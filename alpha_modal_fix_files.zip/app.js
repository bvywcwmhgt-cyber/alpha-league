// ===== Modal hard-close fix (iOS Safari friendly) =====
(function () {
  const SEL = {
    backdrop: '.modal-backdrop, .overlay, [data-modal-backdrop]',
    modal: '.modal, .dialog, [data-modal]',
    close: '.modal-close, .close, [data-close-modal], [aria-label="Close"]',
  };

  function qsaAny(selectors) {
    const out = [];
    selectors.split(',').map(x => x.trim()).forEach(s => {
      out.push(...document.querySelectorAll(s));
    });
    return out;
  }

  function closeModalHard() {
    if (location.hash) history.replaceState(null, '', location.pathname + location.search);
    document.body.classList.remove('modal-open', 'is-modal-open', 'no-scroll');
    qsaAny(SEL.modal).forEach(m => {
      m.style.display = 'none';
      m.setAttribute('aria-hidden', 'true');
    });
    qsaAny(SEL.backdrop).forEach(b => {
      b.style.display = 'none';
    });
  }

  document.addEventListener('click', (e) => {
    const t = e.target;
    if (t && t.closest && t.closest(SEL.close)) {
      e.preventDefault();
      e.stopPropagation();
      closeModalHard();
    }
    if (t && t.matches && t.matches(SEL.backdrop)) {
      e.preventDefault();
      e.stopPropagation();
      closeModalHard();
    }
  }, true);

  document.addEventListener('touchstart', (e) => {
    const t = e.target;
    if (t && t.closest && t.closest(SEL.close)) {
      e.preventDefault();
      e.stopPropagation();
      closeModalHard();
    }
    if (t && t.matches && t.matches(SEL.backdrop)) {
      e.preventDefault();
      e.stopPropagation();
      closeModalHard();
    }
  }, { capture: true, passive: false });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModalHard();
  });

  const isMobile = matchMedia('(max-width: 800px)').matches;
  if (isMobile && location.hash) {
    history.replaceState(null, '', location.pathname + location.search);
  }

  window.closeModalHard = closeModalHard;
})();
